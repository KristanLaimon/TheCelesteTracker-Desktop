local rainbowBerry = {}
rainbowBerry.name = "CollabUtils2/RainbowBerry"
rainbowBerry.depth = -100
rainbowBerry.placements = {
    {
        name = "default",
        data = {
            levelSet = "SpringCollab2020/1-Beginner",
            maps = "",
            requires = ""
        }
    }
}

rainbowBerry.texture = "CollabUtils2/rainbowBerry/rberry0030"

return rainbowBerry
